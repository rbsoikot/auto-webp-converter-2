<?php
/*
Plugin Name: Auto WebP Converter
Description: Automatically converts uploaded images to WebP format and provides a tool to optimize existing images.
Version: 1.0
Author: Your Name
*/

// Hook to convert newly uploaded images to WebP
function convert_to_webp($file) {
    // Check if the uploaded file is an image
    if (strpos($file['type'], 'image') !== false) {
        $image = imagecreatefromstring(file_get_contents($file['file']));

        if ($image !== false) {
            $webp_filename = preg_replace('/\.[^.]+$/', '.webp', $file['file']);

            // Convert the image to WebP format
            if (imagewebp($image, $webp_filename)) {
                // Update the file information
                $file['file'] = $webp_filename;
                $file['type'] = 'image/webp';
                $file['url'] = str_replace(basename($file['url']), basename($webp_filename), $file['url']);
            }

            // Free up memory
            imagedestroy($image);
        }
    }

    return $file;
}
add_filter('wp_handle_upload', 'convert_to_webp');

// Add admin menu for WebP optimization
function awc_add_admin_menu() {
    add_menu_page(
        'WebP Optimizer',
        'WebP Optimizer',
        'manage_options',
        'webp-optimizer',
        'awc_optimizer_page',
        'dashicons-images-alt2',
        100
    );
}
add_action('admin_menu', 'awc_add_admin_menu');

// Admin page for WebP optimization
function awc_optimizer_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Handle bulk optimization of selected images
    if (isset($_POST['awc_optimize_selected']) && !empty($_POST['awc_selected_images'])) {
        check_admin_referer('awc_optimize_selected');
        $selected_images = array_map('intval', $_POST['awc_selected_images']);
        $optimized_count = 0;

        foreach ($selected_images as $attachment_id) {
            $image_path = get_attached_file($attachment_id);
            if (awc_convert_image_to_webp($image_path, $attachment_id)) {
                $optimized_count++;
            }
        }

        echo '<div class="notice notice-success"><p>' . sprintf(__('%d images optimized to WebP.', 'auto-webp-converter'), $optimized_count) . '</p></div>';
    }

    // Display non-WebP images
    $non_webp_images = awc_get_non_webp_images();
    ?>
    <div class="wrap">
        <h1>WebP Optimizer</h1>
        <p>This tool allows you to optimize existing images to WebP format.</p>

        <?php if (!empty($non_webp_images)) : ?>
            <form method="post" action="">
                <?php wp_nonce_field('awc_optimize_selected'); ?>
                <input type="submit" name="awc_optimize_selected" class="button button-primary" value="Optimize Selected Images">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="awc-select-all"></th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($non_webp_images as $image) : ?>
                            <tr id="image-row-<?php echo $image->ID; ?>">
                                <td>
                                    <input type="checkbox" name="awc_selected_images[]" value="<?php echo $image->ID; ?>">
                                </td>
                                <td>
                                    <img src="<?php echo wp_get_attachment_url($image->ID); ?>" style="max-width: 150px; height: auto;">
                                    <br>
                                    <?php echo basename(get_attached_file($image->ID)); ?>
                                </td>
                                <td>
                                    <a href="#" class="button button-secondary awc-optimize-single" data-attachment-id="<?php echo $image->ID; ?>">Optimize to WebP</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
            <script>
                // Add "Select All" functionality
                document.getElementById('awc-select-all').addEventListener('change', function() {
                    var checkboxes = document.querySelectorAll('input[name="awc_selected_images[]"]');
                    checkboxes.forEach(function(checkbox) {
                        checkbox.checked = this.checked;
                    }, this);
                });

                // AJAX optimization for single images
                document.querySelectorAll('.awc-optimize-single').forEach(function(button) {
                    button.addEventListener('click', function(e) {
                        e.preventDefault();
                        var attachmentId = this.getAttribute('data-attachment-id');
                        var row = document.getElementById('image-row-' + attachmentId);

                        // Show loading indicator
                        this.textContent = 'Optimizing...';
                        this.disabled = true;

                        // Send AJAX request
                        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: 'action=awc_optimize_single&attachment_id=' + attachmentId + '&_wpnonce=<?php echo wp_create_nonce('awc_optimize_single'); ?>',
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Remove the row from the table
                                row.remove();
                            } else {
                                alert('Failed to optimize image.');
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('An error occurred while optimizing the image.');
                        });
                    });
                });
            </script>
        <?php else : ?>
            <div class="notice notice-success"><p>All images are already in WebP format. Great job!</p></div>
        <?php endif; ?>
    </div>
    <?php
}

// Get all non-WebP images from the media library
function awc_get_non_webp_images() {
    $args = array(
        'post_type' => 'attachment',
        'post_mime_type' => 'image',
        'posts_per_page' => -1,
        'post_status' => 'inherit',
    );

    $images = get_posts($args);
    $non_webp_images = array();

    foreach ($images as $image) {
        $image_path = get_attached_file($image->ID);
        if (pathinfo($image_path, PATHINFO_EXTENSION) !== 'webp') {
            $non_webp_images[] = $image;
        }
    }

    return $non_webp_images;
}

// Convert a single image to WebP format
function awc_convert_image_to_webp($image_path, $attachment_id) {
    if (!file_exists($image_path)) {
        return false;
    }

    // Load the image
    $image = false;
    $extension = strtolower(pathinfo($image_path, PATHINFO_EXTENSION));

    switch ($extension) {
        case 'jpeg':
        case 'jpg':
            $image = imagecreatefromjpeg($image_path);
            break;
        case 'png':
            $image = imagecreatefrompng($image_path);
            break;
        case 'gif':
            $image = imagecreatefromgif($image_path);
            break;
    }

    if ($image === false) {
        return false;
    }

    // Convert to WebP
    $webp_filename = preg_replace('/\.[^.]+$/', '.webp', $image_path);

    if (imagewebp($image, $webp_filename)) {
        // Update the attachment metadata
        update_attached_file($attachment_id, $webp_filename);
        wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $webp_filename));

        // Free up memory
        imagedestroy($image);

        // Delete the original image
        unlink($image_path);

        return true;
    }

    imagedestroy($image);
    return false;
}

// Handle AJAX request for single image optimization
function awc_ajax_optimize_single() {
    check_ajax_referer('awc_optimize_single');

    if (isset($_POST['attachment_id'])) {
        $attachment_id = intval($_POST['attachment_id']);
        $image_path = get_attached_file($attachment_id);

        if (awc_convert_image_to_webp($image_path, $attachment_id)) {
            wp_send_json_success();
        }
    }

    wp_send_json_error();
}
add_action('wp_ajax_awc_optimize_single', 'awc_ajax_optimize_single');